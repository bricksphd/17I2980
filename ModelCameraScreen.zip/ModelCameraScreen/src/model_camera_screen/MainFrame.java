/*
 * Copyright Brian Ricks, PhD, 2016. bricks at unomaha.edu
 */
package model_camera_screen;

import java.awt.Color;
import java.awt.HeadlessException;
import javax.swing.JFrame;

/**
 *
 * @author bricks
 */
public class MainFrame extends JFrame{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
        MainFrame andrew = new MainFrame();
    }

    public MainFrame()  {
        
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Andrew");
        
        Model model = new Model();
        
        model.cars.add(new Car(0, 0, Color.YELLOW, "Sports Car"));
        
        MainPanel panel = new MainPanel(model);
        
        this.add(panel);
        this.pack();
        
    }
    
    
    
}
