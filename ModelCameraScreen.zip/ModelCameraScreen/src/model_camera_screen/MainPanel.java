/*
 * Copyright Brian Ricks, PhD, 2016. bricks at unomaha.edu
 */

package model_camera_screen;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

/**
/* The class JPanel
*/
public class MainPanel extends JPanel implements MouseListener, MouseMotionListener
{
    /**
    /* Default constructor
    */
    Model model;
   
    Point lastMouseLocation = null;
    
    public MainPanel(Model model)
    {
            this.setPreferredSize(new Dimension(400, 400));
            
            
            this.addMouseListener(this);
            this.addMouseMotionListener(this);
            
            this.model = model;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        
        Graphics2D g2d = (Graphics2D)g;
        
        ///Fill the background
        g2d.setColor(Color.CYAN);
        g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
        
        
        for(Car car : model.cars)
        {
            g2d.setColor(car.getColor());
            
            
            
            g2d.fillRect((int)car.getX(), (int)car.getY(), 3 , 2);
        }
        
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
        lastMouseLocation = e.getPoint();
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        
        int diffX = lastMouseLocation.x - e.getPoint().x;
        int diffY = lastMouseLocation.y - e.getPoint().y;
        
        
        
        
        lastMouseLocation = e.getPoint();
        
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
       
    }
    
    
    
    
}
