/*
 * Copyright Brian Ricks, PhD, 2016. bricks at unomaha.edu
 */

package model_camera_screen;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

/**
/* The class JPanel
*/
public class MainPanel extends JPanel implements MouseListener, MouseMotionListener, MouseWheelListener, KeyListener
{
    /**
    /* Default constructor
    */
    Model model;
   
    Point lastMouseLocation = null;
    
    float cameraX = 0;
    float cameraY = 0;
    
    float cameraZoom = 10;
    
    List<Integer> keysDown = new ArrayList<Integer>();
    
    public MainPanel(Model model)
    {
            this.setPreferredSize(new Dimension(400, 400));
            
            
            this.addMouseListener(this);
            this.addMouseMotionListener(this);
            this.addMouseWheelListener(this);
            this.addKeyListener(this);
            
            this.model = model;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        
        Graphics2D g2d = (Graphics2D)g;
        
        ///Fill the background
        g2d.setColor(Color.CYAN);
        g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
        
        
        //Create the transform to recenter the camera
        //and scale and invert y (we want y up)
        
        AffineTransform transform = new AffineTransform(cameraZoom, 0, 0, cameraZoom, 0, 0);
        transform.translate(this.getWidth()/(2 * cameraZoom) + cameraX, this.getHeight()/(2*cameraZoom)  +cameraY);
        
        
        
        g2d.setTransform(transform);
        
        
        for(Car car : model.cars)
        {
            g2d.setColor(car.getColor());
            
            
            //g2d.fillRect((int)car.getX(), (int)car.getY(), 3 , 2);
            Shape carOutline = new Rectangle2D.Float(car.getX(), car.getY(), 3, 1.5f);
            
            g2d.fill(carOutline);
        }
        
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
        lastMouseLocation = e.getPoint();
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        
        int diffX = lastMouseLocation.x - e.getPoint().x;
        int diffY = lastMouseLocation.y - e.getPoint().y;
        
        
        cameraX -= diffX / cameraZoom;
        cameraY -= diffY / cameraZoom;
        
        
        lastMouseLocation = e.getPoint();
        
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
       
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        
        
        //Don't add and subtract from zoom!!!!
        //Instead, multiply
        
        if(e.getPreciseWheelRotation() > 0)
        {
            cameraZoom *= 1.1;
        }
        else if(e.getPreciseWheelRotation() < 0)
        {
            cameraZoom /= 1.1;
        }
        
       
        
        repaint();
        
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
     
        if(!keysDown.contains(e.getKeyCode()))
            keysDown.add(e.getKeyCode());
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keysDown.remove(e.getKeyCode());
    }
    
    
    
    
}
