/*
 * Copyright Brian Ricks, PhD, 2016. bricks at unomaha.edu
 */

package model_camera_screen;

import java.util.ArrayList;
import java.util.List;

/**
/* The class Model
*/
public class Model
{
    
    List<Car> cars = new ArrayList<Car>();

    void update() {
        
        
        for(Car car : cars)
        {
            car.move(.01f);
        }
    }
    
    
}
